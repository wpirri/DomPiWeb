
<script type="text/javascript" >
// 15 minutos de time-out de la pantalla por seguridad
setTimeout("window.location.replace('<?php echo $INDEX?>');", <?php echo $TIMEOUT?>);
</script>

</html>
