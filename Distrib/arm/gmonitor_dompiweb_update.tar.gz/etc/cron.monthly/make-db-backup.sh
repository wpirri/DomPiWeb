#!/bin/sh

#/usr/local/sbin/make-dompidb-backup.sh
/usr/local/bin/make_dump.sh

