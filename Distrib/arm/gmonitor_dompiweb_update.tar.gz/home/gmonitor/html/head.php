<!DOCTYPE html>
<html lang="es">
<?php 
    include('config.php'); 
    include('session.php');
?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>SYSHOME V 3.0 - <?php echo $TITLE; ?></title>
<?php head_link("css/dompiweb.css"); ?>
<?php head_script("js/ajax.js"); ?>
</head>
