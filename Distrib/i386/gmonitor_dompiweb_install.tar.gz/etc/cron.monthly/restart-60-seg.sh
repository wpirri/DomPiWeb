#!/bin/sh

/usr/bin/logger "Reinicio mensual del Sistema DOMPIWEB en 60 segundos"
/usr/sbin/shutdown --reboot "+60"
