<!DOCTYPE html>
<html lang="es">
<?php
    include('config.php'); 
    include('session.php');
?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>SYSHOME V 3.0 - <?php echo $TITLE; ?></title>
<link href="css/dompiweb.css" rel="stylesheet" type="text/css" />
<link href="css/abm.css" rel="stylesheet" type="text/css" />
<script src="js/ajax.js" type="text/javascript"></script>
<script src="js/abm.js" type="text/javascript"></script>
<script src="js/jquery.min.js" type="text/javascript"></script>
</head>
