<?php
session_start();

?>
<script type="text/javascript" >
//window.location.replace('login.php');
</script>
