<?php
$INDEX='index.html';
$MAIN='planta.php';
$CONFIG_MENU='config_menu.php';
$AUTO_MENU='auto_menu.php';

$TIMEOUT=900000;
?>
