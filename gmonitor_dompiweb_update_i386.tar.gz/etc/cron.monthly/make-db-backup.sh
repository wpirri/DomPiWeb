#!/bin/sh

/usr/local/sbin/make-dompidb-backup.sh

